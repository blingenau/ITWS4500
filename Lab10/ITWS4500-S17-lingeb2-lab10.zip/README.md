I chose Charts.js for my data visualization. It had the easiest learning curve and had some really nice charts.
The visualizations I chose are as follows:
 - Number of Hashtags Used: I chose this to show a trend with how many hashtags people use when talking about a singular subject. Do they congregate towards a single number?
 - Following vs. Followers: I chose this to relate how many twitter users a preson is following to the number who follow him/her. It was seen that usually with more followers, someone would be following less users.
 - Language Frequency: Lastly, I chose language frequency to show what the language preferences are of people talking about a single topic.