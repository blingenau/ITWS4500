Install Instructions:
 - Copy the files to your system
 - Run `npm install`
 - Run `mongod` in one terminal
 - Run `node server.js` in another
 - Navigate to `http://localhost:3000/`
 - Enjoy your tweets

This was a nice wrap-up to the multitude of related labs we've had. Put my own spin on it,
made a nice landing page. I love working with the backend but angular has made working with
the frontend much more enjoyable for me.
