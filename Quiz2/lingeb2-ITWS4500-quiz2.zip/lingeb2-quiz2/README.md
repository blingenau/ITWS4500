Install Instructions:
 - Copy the files to your system
 - Run `npm install`
 - Run `mongod` in one terminal
 - Run `node server.js` in another
 - Navigate to `http://localhost:8000/`
 - Enjoy your weather data