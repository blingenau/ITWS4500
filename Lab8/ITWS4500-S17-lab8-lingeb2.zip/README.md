What dataset did you use and why? 
    I picked the IMDB dataset. I'm really into movies and wanted to relate the IMDB score to it's content rating.
What did you learn about the dataset from your exploration?
    I think movies that are around an R rating have better average ratings.
What challenges did you face (due to R, the dataset, or formating), and how did you overcome them?
    I still don't really understand how to change up my plots. It was hard to get it not looking cramped.

got my data from https://www.kaggle.com/deepmatrix/imdb-5000-movie-dataset