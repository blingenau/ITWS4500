Had a very hard time getting the responsiveness functionality with bootstrap to work. Never been
much of a front end guy so I was thankful for the practice and now know that I need to focus on that.
The actual reading in of the JSON was fine. 
I used JQuery to make the ticker functionality. Basically just .slideDown() to get that sliding in effect
and I popped out the 5th element to make room for the new one
For the responsiveness I used Bootstrap rows and columns.
The responsiveness is quite lacking, I ust couldn't get it to play nice. 