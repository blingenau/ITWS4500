INDIVIDUAL

waffle.JPG shows the software I used for my bugtracking. It's called waffle.io
testIssueWaffle.JPG shows creating an issue in the software.
testIssueGithub.JPG shows that the newly created issue shows up in the remote github repo.
The link to my github repo for ITWS4500 is https://github.com/blingenau/ITWS4500

GROUP

Menuoso is a MEAN stack Web app integrated with Raspberry Pi to provide restaurant managers with digital menus that are easy to edit, arrange, and style. 
The link to our github repo is https://github.com/ddbruce/websci-group-2
Our server is hosted at http://websci.w1bbb.com/
Users have been created for you both on our server. The user and pass are your first names (richard/richard & corey/corey)
I also added corey's public rsa key. I've never done anything with rsa keys before so I'm not 100% sure I got it right.
For bug tracking we're primarily using Github's issue tracker but also Waffle.io for it's nice issue status features
You should be added on our repo as well.