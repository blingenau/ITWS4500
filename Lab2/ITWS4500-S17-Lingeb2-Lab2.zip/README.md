I decided to go with OpenWeatherMap's API. It seemed robust and easy to use. 
It gave me a forecast for every 3 hours, so I cycled through each of those every 3 seconds,
using CSS animations and transitions to get a sliding effect. 
I also used bootstrap's grid system to get a respnsive design.
I learned a lot more about boostrap and CSS from this lab. This is the first time I dedicated some real
time to make sure the responiveness and animations/transitions were done well (enough, I'm not much of a front-end guy).
I definitely liked the API part of the lab more, I've always been more of a backend guy. Messing around with APIs is fun.