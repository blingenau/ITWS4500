This lab was easier than I thought it to be. I got a lot of 
experience setting up a mongo database and schemas from our group project 
so that part was super easy. After that it was just bundling everything together 
with the previous lab's code.